<!-- ======= Header ======= -->
<header id="header" class="fixed-top">
    <div class="container">

      <nav>
         <div class="logo-log">
          <a href="/"><img src="../img/soraksorai.png" alt="CRED" class="logo"/></a>
        </div>
      </nav>

    </div>

</header>