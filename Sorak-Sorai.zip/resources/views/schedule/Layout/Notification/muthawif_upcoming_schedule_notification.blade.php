<a href="/scheduleDetail/{{ $notification->data['schedule']['id'] }}">
    {{ $notification->data['user']['name'] }}, your <strong>{{ $notification->data['schedule']['name'] }} Schedule</strong> will start in <span>one hour</span>
</a>